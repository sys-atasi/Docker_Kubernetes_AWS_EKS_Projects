package com.example.myorderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyorderserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
