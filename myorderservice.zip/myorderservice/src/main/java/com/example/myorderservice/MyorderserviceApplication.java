package com.example.myorderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyorderserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyorderserviceApplication.class, args);
	}

}
